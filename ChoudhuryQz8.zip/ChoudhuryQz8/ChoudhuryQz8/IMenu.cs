﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    interface IMenu
    {
        void ShowMenu();
        void PromptName();

        void PromptBeverage();

        void PromptSize();

        void PromptExtra();

        void ShowInfo();
    }
}
