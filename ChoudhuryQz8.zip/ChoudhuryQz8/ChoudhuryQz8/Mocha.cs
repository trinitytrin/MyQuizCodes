﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class Mocha : IExtraDecorator
    {
        IBeverage ABev;

        string description = " Mocha ";
        double sCost = 0.39;
        double mCost = 0.59;
        double lCost = 0.79;
        string size;
        public double Cost
        {
            get
            {
                if (this.Size == "Small")
                    return (ABev.Cost+ sCost);
                else if (this.Size == "Medium")
                    return (ABev.Cost+ mCost);
                else if (this.Size == "Large")
                    return (ABev.Cost+lCost);

                return 0.0;
            }
        }

        public string Description
        {
            get
            {
                if (ABev.Description == "Expresso" || ABev.Description == "House Blend" || ABev.Description == "Dark Roast")
                    return description;
                else 
                    return (ABev.Description + description);
            }
        }

        public string Size
        {
            get
            {
                return size;
            }

            set
            {
                size = value;
            }
        }

        public Mocha(IBeverage bev)
        {
            ABev = bev;
        }

    }
}
