﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class HouseBlend : IBeverage
    {
        string description = "House Blend";
        double sCost = 2.99;
        double mCost = 3.99;
        double lCost = 4.99;
        string size;


        public double Cost
        {
            get
            {
                if (this.Size == "Small")
                    return sCost;
                else if (this.Size == "Medium")
                    return mCost;
                else if (this.Size == "Large")
                    return lCost;

                return 0.0;

            }
        }

        public string Description
        {
            get
            {
                return description;
            }
        }

        public string Size
        {
            get
            {
                return size;
            }

            set
            {
                size = value;
            }
        }
    }
}
