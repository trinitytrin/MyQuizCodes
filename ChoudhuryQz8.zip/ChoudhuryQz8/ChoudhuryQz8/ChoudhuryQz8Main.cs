﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class ChoudhuryQz8Main
    {
        static void Main(string[] args)
        {
            try
            {
                MainProgram mp = new MainProgram();
                mp.RunMainProgram();

                Console.WriteLine("\n\nPlease press any key to terminate the program\n");
                Console.ReadKey();
                
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception caught in Main program {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }
    }
}
