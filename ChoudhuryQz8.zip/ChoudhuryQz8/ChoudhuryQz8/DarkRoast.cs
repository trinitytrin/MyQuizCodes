﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class DarkRoast : IBeverage
    {
        string description = "Dark Roast";
        double sCost = 3.49;
        double mCost = 4.49;
        double lCost = 5.49;
        string size;


        public double Cost
        {
            get
            {
                if (this.Size == "Small")
                    return sCost;
                else if (this.Size == "Medium")
                    return mCost;
                else if (this.Size == "Large")
                    return lCost;

                return 0.0;

            }
        }

        public string Description
        {
            get
            {
                return description;
            }
        }

        public string Size
        {
            get
            {
                return size;
            }

            set
            {
                size = value;
            }
        }
    }
}
