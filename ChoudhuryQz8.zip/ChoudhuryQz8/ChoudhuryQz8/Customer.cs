﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class Customer : ICustomer
    {
        string name;
        string sizechoice;
        IBeverage bevchoice;
        string baseBev;

        double totalcost;


        public IBeverage BevChoice
        {
            get
            {
                return bevchoice;
            }

            set
            {
                bevchoice = value;
            }
        }



        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string SizeChoice
        {
            get
            {
                return sizechoice;
            }

            set
            {
                sizechoice = value;
            }
        }

        public string BaseBev
        {
            get
            {
                return baseBev;
            }

            set
            {
                baseBev = value;
            }
        }

        public double GetTotalCost()
        {
            try
            {
                if (this.SizeChoice == "Small")
                    BevChoice.Size = "Small";
                else if (this.SizeChoice == "Medium")
                    BevChoice.Size = "Medium";
                else if (this.SizeChoice == "Large")
                    BevChoice.Size = "Large";

                totalcost = BevChoice.Cost;

                return totalcost;
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception caught in GetTotalCost method of Customer class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);
                return 0.0;

            }


        }

        public void ShowDetail()
        {
            try
            {
                string extraval;
                if (this.BevChoice.Description == "Expresso" || this.BevChoice.Description == "House Blend" || this.BevChoice.Description == "Dark Roast")
                    extraval = " ";
                else
                    extraval = this.BevChoice.Description;

                Console.WriteLine("\n\n-------- Customer's cost till now ------------- ");
                Console.WriteLine("Customer : {0}", this.Name);
                Console.WriteLine("Beverage : {0}", this.BaseBev);
                Console.WriteLine("Size : {0}", this.SizeChoice );

                Console.WriteLine("Extras : {0}", extraval);
                Console.WriteLine("Total Cost : {0}\n\n", this.GetTotalCost());

                //this.PromptExtra();



            }

            catch (Exception e)
            {
                Console.WriteLine("Exception caught in ShowDetail method of Customer class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }

        public Customer(string s)
        {
            if (s.Length <1 )
                this.Name = "Unknown Customer";
            else
                this.Name = s;
        }
        
    }
}
