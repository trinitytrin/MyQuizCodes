﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class Whip : IExtraDecorator
    {
        IBeverage ABev;

        string description = " Whip ";
        double sCost = 0.29;
        double mCost = 0.49;
        double lCost = 0.69;
        string size;
        public double Cost
        {
            get
            {
                if (this.Size == "Small")
                    return (ABev.Cost + sCost);
                else if (this.Size == "Medium")
                    return (ABev.Cost + mCost);
                else if (this.Size == "Large")
                    return (ABev.Cost + lCost);

                return 0.0;
            }
        }

        public string Description
        {
            get
            {
                if (ABev.Description == "Expresso" || ABev.Description == "House Blend" || ABev.Description == "Dark Roast")
                    return description;
                else
                    return (ABev.Description + description);
            }
        }

        public string Size
        {
            get
            {
                return size;
            }

            set
            {
                size = value;
            }
        }

        public Whip(IBeverage bev)
        {
            ABev = bev;
        }
    }
}
