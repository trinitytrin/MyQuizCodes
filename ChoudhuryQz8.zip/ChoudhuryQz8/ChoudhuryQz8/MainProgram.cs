﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class MainProgram : IMainProgram
    {
        public void RunMainProgram()
        {
            try
            {
                Console.WriteLine("Quiz 8: Decoration Pattern - Open Close Principle: Starts here.. \n");

                Menu menu = new Menu();

                menu.ShowMenu();
                menu.PromptName();
            



            }

            catch(Exception e)
            {
                Console.WriteLine("Exception caught in RunMainProgram method of MainProgram class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }
    }
}
