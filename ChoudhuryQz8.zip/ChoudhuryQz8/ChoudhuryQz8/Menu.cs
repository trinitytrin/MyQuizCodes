﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    class Menu : IMenu
    {
        Customer customer;
        public void ShowMenu()
        {
            
            try
            {
                Console.WriteLine("Beverage rates are as follows: \n");                            
                Console.WriteLine(String.Format("{0,-20}", "Name") + String.Format("{0,-10}","Small")+ String.Format("{0,-10}", "Medium")+ String.Format("{0,-10}", "Large"));
                Console.WriteLine("---------------------------------------------------");
                Console.WriteLine(String.Format("{0,-20}", "Expresso") + String.Format("{0,-10}", "$3.99") + String.Format("{0,-10}", "$4.99") + String.Format("{0,-10}", "$5.99"));
                Console.WriteLine(String.Format("{0,-20}", "House Blend") + String.Format("{0,-10}", "$2.99") + String.Format("{0,-10}", "$3.99") + String.Format("{0,-10}", "$4.99"));
                Console.WriteLine(String.Format("{0,-20}", "Dark Roast") + String.Format("{0,-10}", "$3.49") + String.Format("{0,-10}", "$4.49") + String.Format("{0,-10}", "$5.49"));

                Console.WriteLine("Extra rates are as follows: \n");
                Console.WriteLine(String.Format("{0,-20}", "Name") + String.Format("{0,-10}", "Small") + String.Format("{0,-10}", "Medium") + String.Format("{0,-10}", "Large"));
                Console.WriteLine("---------------------------------------------------");
                Console.WriteLine(String.Format("{0,-20}", "Mocha") + String.Format("{0,-10}", "$0.39") + String.Format("{0,-10}", "$0.59") + String.Format("{0,-10}", "$0.79"));
                Console.WriteLine(String.Format("{0,-20}", "Soy") + String.Format("{0,-10}", "$0.39") + String.Format("{0,-10}", "$0.59") + String.Format("{0,-10}", "$0.79"));
                Console.WriteLine(String.Format("{0,-20}", "Whip") + String.Format("{0,-10}", "$0.29") + String.Format("{0,-10}", "$0.49") + String.Format("{0,-10}", "$0.69"));
                Console.WriteLine("\n\n\n");
            }

            catch (IOException e)
            {
                Console.WriteLine("Exception caught in ShowMenu method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }

        public void PromptName()
        {
            try
            {
                string prompt1;
                Console.Write("Enter Customer Name (Enter for Default, q to Quit) :");
                prompt1 = Console.ReadLine();

                if (prompt1 == "q")
                    this.Terminate();
                else
                {
                    this.customer = new Customer(prompt1);
                    this.PromptBeverage();
                }



            }

            catch(IOException e)
            {
                Console.WriteLine("Exception caught in PromptName method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }

        public void PromptBeverage()
        {
            try
            {
                string prompt1;
                Console.WriteLine("\n\nBeverage choices are :\n1. Expresso\n2. House Blend\n3. Dark Roast\n4. Done\n");
                Console.Write("Enter menu choice (1 - 4) : ");
                prompt1 = Console.ReadLine();

                if (prompt1 == "4")
                    this.Terminate();
                else if (prompt1 == "1")
                {
                    customer.BevChoice = new Expresso();
                    customer.BaseBev = "Expresso";
                    this.PromptSize();
                }
                else if (prompt1 == "2")
                {
                    customer.BevChoice = new HouseBlend();
                    customer.BaseBev = "House Blend";
                    this.PromptSize();
                }
                else if (prompt1 == "3")
                {
                    customer.BevChoice = new DarkRoast();
                    customer.BaseBev = "Dark Roast";
                    this.PromptSize();
                }
                else
                    this.PromptBeverage();

            }

            catch (IOException e)
            {
                Console.WriteLine("Exception caught in PromptBeverage method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }

        public void PromptSize()
        {
            try
            {
                string prompt1;
                Console.WriteLine("\n\nSize choices are :\n1. Small\n2. Medium\n3. Large\n4. Done\n");
                Console.Write("Enter menu choice (1 - 4) : ");
                prompt1 = Console.ReadLine();

                if (prompt1 == "4")
                    this.Terminate();
                else if (prompt1 == "1")
                {
                    customer.SizeChoice = "Small";
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else if (prompt1 == "2")
                {
                    customer.SizeChoice = "Medium";
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else if (prompt1 == "3")
                {
                    customer.SizeChoice = "Large";
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else
                    this.PromptSize();

            }

            catch (IOException e)
            {
                Console.WriteLine("Exception caught in PromptSize method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }

        }


        public void PromptExtra()
        {
            try
            {
                string prompt1;
                Console.WriteLine("\n\nExtras choices are :\n1. Mocha\n2. Whip\n3. Soy\n4. Done\n");
                Console.Write("Enter menu choice (1 - 4) : ");
                prompt1 = Console.ReadLine();

                if (prompt1 == "4")
                {
                    this.ShowInfo();
                    this.PromptName();
                }
                else if (prompt1 == "1")
                {
                    this.customer.BevChoice = new Mocha(customer.BevChoice);
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else if (prompt1 == "2")
                {
                    this.customer.BevChoice = new Whip(customer.BevChoice);
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else if (prompt1 == "3")
                {
                    this.customer.BevChoice = new Soy(customer.BevChoice);
                    this.ShowInfo();
                    this.PromptExtra();
                }
                else
                    this.PromptExtra();

            }

            catch (IOException e)
            {
                Console.WriteLine("Exception caught in PromptExtra method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }

        }

        public void ShowInfo()
        {
            try
            {
                this.customer.ShowDetail();

                //this.PromptExtra();



            }

            catch (Exception e)
            {
                Console.WriteLine("Exception caught in ShowInfo method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }

        public void Terminate()
        {
            try
            {
                Console.WriteLine("\n\nPlease press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }

            catch(Exception e)
            {
                Console.WriteLine("Exception caught in Terminate method of Menu class {0}", e);

                Console.WriteLine("Please press any key to terminate the program\n");
                Console.ReadKey();
                Environment.Exit(0);

            }
        }
    }
}
