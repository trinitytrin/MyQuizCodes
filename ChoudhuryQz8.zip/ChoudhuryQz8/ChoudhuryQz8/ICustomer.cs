﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoudhuryQz8
{
    interface ICustomer
    {
        string Name{ get; set;}

        IBeverage BevChoice { get; set; }

        string BaseBev{ get; set; }

        string SizeChoice { get; set; }

        double GetTotalCost();

        void ShowDetail();
    }
}
